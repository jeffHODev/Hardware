#ifndef _key_H_
#define _key_H_ 1 
//�����˿ڶ���
/*
sbit  Key_up=PD3; 
sbit  Key_down=PD1; 
sbit  Key_shift=PC12;
sbit  Key_enter=PC10;
*/
/**********����*********************/
#define Key_up       GPIOD->IDR&(1<<1)
#define Key_down     GPIOD->IDR&(1<<3)
#define Key_shift    GPIOC->IDR&(1<<12)
#define Key_enter    GPIOC->IDR&(1<<10)	  

//��������
unsigned char        VKey1CheckNum=0xff;   //����1,��1��
unsigned char        VKey2CheckNum=0xff;   //����2,��1��
unsigned char        VKey3CheckNum=0xff;   //����3,��λ��
unsigned char        VKey4CheckNum=0xff;   //����4,�˳���
 
unsigned char        BEnterKeyFlag=0;           //ȷ�ϱ�־
unsigned char        BShiftKeyFlag=0;           //��λ��־
unsigned char        BDecKeyFlag=0;             //��һ��־
unsigned char        BIncKeyFlag=0;             //��һ��־
//
/********************************************************************************
��������:key
��������:���ж��ӳ���
��ڲ���:k1~k4��Ӧp1.0~p1.3
���ڲ���:��
ʹ�÷�Χ:
��������:����
��д����:2009-10-16
�޸�����:
�޸�����:2009-10-16
*********************************************************************************/
void  key_panduan(void)               
{
    VKey1CheckNum=VKey1CheckNum<<1;
	VKey2CheckNum=VKey2CheckNum<<1;
	VKey3CheckNum=VKey3CheckNum<<1;
	VKey4CheckNum=VKey4CheckNum<<1;
	//����1---��һ
	if(Key_up)
		VKey1CheckNum|=1;	
	if(VKey1CheckNum==0x0F)
		BIncKeyFlag=1;
	//����2---��һ
	if(Key_down)
		VKey2CheckNum|=1;	
	if(VKey2CheckNum==0x0F)
		BDecKeyFlag=1;
	//����3---��λ
	if(Key_shift)
		VKey3CheckNum|=1;	
	if(VKey3CheckNum==0x0F)
		BShiftKeyFlag=1;
    //����3---ȷ��
	if(Key_enter)
		VKey4CheckNum|=1;	
	if(VKey4CheckNum==0x0F)
		BEnterKeyFlag=1;
} 
/********************************************************************************
��������: keypro
��������:����������
��ڲ���:k1~k4��Ӧp1.0~p1.3
���ڲ���:��
ʹ�÷�Χ:
��������:����
��д����:2009-10-16
�޸�����:
�޸�����:2009-10-16
*********************************************************************************/
void  keypro(void)            
{
        //ȷ�ϼ�
	    if(BEnterKeyFlag)         //�����ж�
		{ 
	     if(Sounds_flg==1)
		 fengming_flg=1;
		 LCD_CLS();               //ˢ��  	
		 key_tree++;              //��������һ
		 if(key_tree>0&&key_tree<=3)           //   
		 {
		  page=1;
//		  EX0=0;    //��ӵ�
		 }
		 if(key_tree>3&&key_tree<=6)           //   
		 {
		  page=2;
		 }
		 if(key_tree>6&&key_tree<=9)           //   
		 {
		  page=3;
		 }
		  if(key_tree>9)           //   
		 {
		  page=0;
		  flash_flg=0;		      //��˸��־Ϊ0
//		  EX0=1;                  //���ⲿ�ж�
          LCD_XM();               //�����˵�   
          key_tree=0;
		 }
		 shift=0;                 //��λ��Ϊ0  		  
		 while(!Key_enter);       //�ȴ��ͷ�
		 BEnterKeyFlag=0;         //���־
		}
		//��һ��
		if(BIncKeyFlag)         
		{
	     if(Sounds_flg==1)
		 fengming_flg=1;
		 switch(key_tree)
		 {
		  case 1:
		  break;
		  case 2: ALM_flg=!ALM_flg;			    //������
		  break;
		  case 3: beep_flg=!beep_flg;	        //��������
		  break;
		  case 4: bluetooth_flg=!bluetooth_flg; //������
		  break;
		  case 5: Sounds_flg=!Sounds_flg;	    //��������
		  break;
		  case 6: switch(shift)
		          { 
				   case 0:
				   SPO2HI_buf[0]++;
				   if(SPO2HI_buf[0]>9)
				   SPO2HI_buf[0]=0;
				   break;
				   case 1:
				   SPO2HI_buf[1]++;
				   if(SPO2HI_buf[1]>9)
				   SPO2HI_buf[1]=0;
				   break;
				   case 2:
				   SPO2HI_buf[2]++;
				   if(SPO2HI_buf[2]>9)
				   SPO2HI_buf[2]=0;
				   break;
				   default:
				   break;
				  }
				  SPO2HI=SPO2HI_buf[2]*100+SPO2HI_buf[1]*10+SPO2HI_buf[0]; 
		          //SPO2HI++;if(SPO2HI>100)SPO2HI=0;
		          data_proc(SPO2HI);        //Ѫ�����Ͷȱ�������
	              SPO2HI_buf[2]=bw;
	              SPO2HI_buf[1]=sw;
	              SPO2HI_buf[0]=gw;
		  break;
		  case 7: switch(shift)
		          { 
				   case 0:
				   SPO2LO_buf[0]++;
				   if(SPO2LO_buf[0]>9)
				   SPO2LO_buf[0]=0;
				   break;
				   case 1:
				   SPO2LO_buf[1]++;
				   if(SPO2LO_buf[1]>9)
				   SPO2LO_buf[1]=0;
				   break;
				   case 2:
				   SPO2LO_buf[2]++;
				   if(SPO2LO_buf[2]>9)
				   SPO2LO_buf[2]=0;
				   break;
				   default:
				   break;
				  }
				  SPO2LO=SPO2LO_buf[2]*100+SPO2LO_buf[1]*10+SPO2LO_buf[0]; 
		          //SPO2LO++;if(SPO2LO>100)SPO2LO=0;
		  		  data_proc(SPO2LO);        //Ѫ�����Ͷȱ�������
	              SPO2LO_buf[2]=bw;
	              SPO2LO_buf[1]=sw;
	              SPO2LO_buf[0]=gw;
		          break;
		  case 8: switch(shift)
		          { 
				   case 0:
				   PRHI_buf[0]++;
				   if(PRHI_buf[0]>9)
				   PRHI_buf[0]=0;
				   break;
				   case 1:
				   PRHI_buf[1]++;
				   if(PRHI_buf[1]>9)
				   PRHI_buf[1]=0;
				   break;
				   case 2:
				   PRHI_buf[2]++;
				   if(PRHI_buf[2]>9)
				   PRHI_buf[2]=0;
				   break;
				   default:
				   break;
				  }
				  PRHI=PRHI_buf[2]*100+PRHI_buf[1]*10+PRHI_buf[0]; 
		          //PRHI++; if(PRHI>100)PRHI=0;
		  		  data_proc(PRHI);         //������������
	              PRHI_buf[2]=bw;
	              PRHI_buf[1]=sw;
	              PRHI_buf[0]=gw;	
		  break;
		  case 9: switch(shift)
		          { 
				   case 0:
				   PRLO_buf[0]++;
				   if(PRLO_buf[0]>9)
				   PRLO_buf[0]=0;
				   break;
				   case 1:
				   PRLO_buf[1]++;
				   if(PRLO_buf[1]>9)
				   PRLO_buf[1]=0;
				   break;
				   case 2:
				   PRLO_buf[2]++;
				   if(PRLO_buf[2]>9)
				   PRLO_buf[2]=0;
				   break;
				   default:
				   break;
				  }
				  PRLO=PRLO_buf[2]*100+PRLO_buf[1]*10+PRLO_buf[0]; 
		          //PRLO++; if(PRLO>100)PRLO=0;
		  		  data_proc(PRLO);         //������������
	              PRLO_buf[2]=bw;
	              PRLO_buf[1]=sw;
	              PRLO_buf[0]=gw;  
		  break;
		  default:break;
		 }
		 while(!Key_up);  
		 BIncKeyFlag=0;    
		}
		//��һ��
	    if(BDecKeyFlag)       
		{
		 if(Sounds_flg==1)
		 fengming_flg=1;
		 switch(key_tree)
		 {
		  case 1:
		  break;
		  case 2: ALM_flg=!ALM_flg;		   	    //������־
		  break;
		  case 3: beep_flg=!beep_flg;		    //������־
		  break;
		  case 4: bluetooth_flg=!bluetooth_flg; //������־
		  break;
		  case 5: Sounds_flg=!Sounds_flg;	    //������־
		  break;
		  case 6: switch(shift)
		          { 
				   case 0:
				   if(SPO2HI_buf[0]>0)
				   SPO2HI_buf[0]--;
				   break;
				   case 1:
				   if(SPO2HI_buf[1]>0)
				   SPO2HI_buf[1]--;
				   break;
				   case 2:
				   if(SPO2HI_buf[2]>0)
				   SPO2HI_buf[2]--;
				   break;
				   default:
				   break;
				  }
				  SPO2HI=SPO2HI_buf[2]*100+SPO2HI_buf[1]*10+SPO2HI_buf[0];
		          //if(SPO2HI>0)SPO2HI--;	 		 
		          data_proc(SPO2HI);        //Ѫ�����Ͷȱ�������
	              SPO2HI_buf[2]=bw;
	              SPO2HI_buf[1]=sw;
	              SPO2HI_buf[0]=gw;
		  break;
		  case 7: switch(shift)
		          { 
				   case 0:
				   if(SPO2LO_buf[0]>0)
				   SPO2LO_buf[0]--;
				   break;
				   case 1:
				   if(SPO2LO_buf[1]>0)
				   SPO2LO_buf[1]--;
				   break;
				   case 2:
				   if(SPO2LO_buf[2]>0)
				   SPO2LO_buf[2]--;
				   break;
				   default:
				   break;
				  }
				  SPO2LO=SPO2LO_buf[2]*100+SPO2LO_buf[1]*10+SPO2LO_buf[0];
		          //if(SPO2LO>0)SPO2LO--;
		  		  data_proc(SPO2LO);        //Ѫ�����Ͷȱ�������
	              SPO2LO_buf[2]=bw;
	              SPO2LO_buf[1]=sw;
	              SPO2LO_buf[0]=gw;
		  break;
		  case 8:switch(shift)
		          { 
				   case 0:
				   if(PRHI_buf[0]>0)
				   PRHI_buf[0]--;
				   break;
				   case 1:
				   if(PRHI_buf[1]>0)
				   PRHI_buf[1]--;
				   break;
				   case 2:
				   if(PRHI_buf[2]>0)
				   PRHI_buf[2]--;
				   break;
				   default:
				   break;
				  }
				  PRHI=PRHI_buf[2]*100+PRHI_buf[1]*10+PRHI_buf[0];
		          //if(PRHI>0) PRHI--;
		  		  data_proc(PRHI);         //������������
	              PRHI_buf[2]=bw;
	              PRHI_buf[1]=sw;
	              PRHI_buf[0]=gw;		   
		          break;
		  case 9: switch(shift)
		          { 
				   case 0:
				   if(PRLO_buf[0]>0)
				   PRLO_buf[0]--;
				   break;
				   case 1:
				   if(PRLO_buf[1]>0)
				   PRLO_buf[1]--;
				   break;
				   case 2:
				   if(PRLO_buf[2]>0)
				   PRLO_buf[2]--;
				   break;
				   default:
				   break;
				  }
				  PRLO=PRLO_buf[2]*100+PRLO_buf[1]*10+PRLO_buf[0];
		          //if(PRLO>0) PRLO--;
		  		  data_proc(PRLO);        //������������
	              PRLO_buf[2]=bw;
	              PRLO_buf[1]=sw;
	              PRLO_buf[0]=gw;  
		  break;
		  default:break;
		 }	 	 
		 while(!Key_down);  
		 BDecKeyFlag=0;   
		}
		//��λ��
	    if(BShiftKeyFlag)         
		{ 	
		 if(Sounds_flg==1)
		 fengming_flg=1;	
		 shift++;
		 if(shift>2)
		 shift=0;
		 while(!Key_shift);   
		 BShiftKeyFlag=0;	
		}
}  
#endif
 