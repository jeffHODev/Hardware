#if !defined( _INCLUDE_H )
#define _INCLUDE_H

#include <stm32f10x_lib.h>                        // STM32F10x Library Definitions
#include "stm32f10x_it.h"
//#include "stdio.h"
#include "string.h"
#include "math.h"


#endif

