package com.hekangyuan.nivi1000.serialport_api;

import com.hekangyuan.nivi1000.model.SBPBean;

public interface ParseBPCallBack {

    void onParseSuccess(SBPBean sbpBean);
}
