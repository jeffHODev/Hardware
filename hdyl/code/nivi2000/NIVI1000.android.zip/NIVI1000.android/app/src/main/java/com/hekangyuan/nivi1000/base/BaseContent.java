package com.hekangyuan.nivi1000.base;

/**
 * File descripition:

 */

public class BaseContent {
    //base Ip
    public static String baseUrl = "http://www.energy-link.com.cn/";
    //服务器返回成功的 cdoe
    public static int basecode = 1;
    public static int baseecode = 0;
    public static int basecodet = 2;
}
