package com.hekangyuan.nivi1000.serialport_api;

import com.hekangyuan.nivi1000.model.SerialBean;

public interface ParseSerialCallBack {

    void onParseSuccess(SerialBean serialBean);
}
