package com.hekangyuan.nivi1000.model;

public class PDFBean {

    private  String  PDFByte;


    public String getPDFByte() {
        return PDFByte;
    }

    public void setPDFByte(String PDFByte) {
        this.PDFByte = PDFByte;
    }
}
