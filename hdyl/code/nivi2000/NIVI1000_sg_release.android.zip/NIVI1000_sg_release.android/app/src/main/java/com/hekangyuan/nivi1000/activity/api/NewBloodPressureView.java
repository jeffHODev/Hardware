package com.hekangyuan.nivi1000.activity.api;


import com.hekangyuan.nivi1000.base.mvp.BaseJsonMsg;
import com.hekangyuan.nivi1000.base.mvp.BaseView;
import com.hekangyuan.nivi1000.model.BloodPressureBean;
import com.hekangyuan.nivi1000.model.LoginBean;

/**
 * File descripition:
 */

public interface NewBloodPressureView extends BaseView {
    void onMainSuccess(BaseJsonMsg<BloodPressureBean> o);

//    void onUpLoadImgSuccess(BaseModel<Object> o);

}
