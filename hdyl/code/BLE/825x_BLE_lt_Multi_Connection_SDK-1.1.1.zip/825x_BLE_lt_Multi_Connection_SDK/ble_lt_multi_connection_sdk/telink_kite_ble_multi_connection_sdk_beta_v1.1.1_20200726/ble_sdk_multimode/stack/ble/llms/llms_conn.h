/********************************************************************************************************
 * @file     llms_conn.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     July. 4, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/

#ifndef LLMS_CONN_H_
#define LLMS_CONN_H_

#include "drivers.h"
#include "stack/ble/llms/llms.h"
#include "stack/ble/llms/llms_config.h"
#include "stack/ble/blt_config.h"
#include "stack/ble/ble_format.h"
#include "stack/ble/crypt/aes_ccm.h"
#include "stack/ble/llms/llms_slot.h"

/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/

/////////////////////////////////////////////////////////////////////////////
#define 		LL_ROLE_MASTER              					0
#define 		LL_ROLE_SLAVE               					1

#define			HANDLE_STK_FLAG									BIT(15)

/////////////////////////////////////////////////////////////////////////////
#define			MAX_OCTETS_DATA_LEN_27							27
#define			MAX_OCTETS_DATA_LEN_EXTENSION					251


#define			LL_PACKET_OCTET_TIME(n)							((n) * 8 + 112)

#define 		DATA_LENGTH_REQ_PENDING							1
#define			DATA_LENGTH_REQ_DONE							2




#define			BLMS_EARLY_CAL_MAP_TO_SAVE_TIME_EN				1   //when calculate new channel map in BRX/BTX start, 70uS is used


#if (BLMS_CONN_SLAVE_EN)
	#define			BLMS_SLAVE_CONN_UPDATE_EN						1
#endif

#define			SNNESN_STORE_BY_SW								0
#define			SNNESN_STORE_BY_HW								1
#define			BLMS_SN_NESN_STORE_MODE							SNNESN_STORE_BY_HW

#if(BLMS_SN_NESN_STORE_MODE == SNNESN_STORE_BY_HW)
	#define			DBG_SNNESN_EN								0
	#define	        FIX_RX_BOUNDARY_HWSW_CONSISTENCY            0
#else
	#define	        FIX_RX_BOUNDARY_HWSW_CONSISTENCY            1
#endif


//////////////////////////////// LL ENC ///////////////////////////////////
#define			MS_LL_ENC_OFF									0
#define			MS_LL_ENC_REQ									1
#define			MS_LL_ENC_RSP_T									2
#define			MS_LL_ENC_START_REQ_T							3
#define			MS_LL_ENC_START_REQ								4
#define			MS_LL_ENC_START_RSP_T							5
#define			MS_LL_ENC_PAUSE_REQ								6
#define			MS_LL_ENC_PAUSE_RSP_T							7
#define			MS_LL_ENC_PAUSE_RSP								8
#define			MS_LL_REJECT_IND_T								9
#define         MS_LL_ENC_SMP_INFO_S                			10
#define         MS_LL_ENC_SMP_INFO_E                			11

#define			MS_CONN_ENC_CHANGE								BIT(7)
#define			MS_CONN_ENC_REFRESH								BIT(6)
#define			MS_CONN_ENC_REFRESH_T							BIT(5)





#define		 	CONN_STATUS_DISCONNECT							0   //disconnect must be "0"
#define			CONN_STATUS_COMPLETE							1
#define			CONN_STATUS_ESTABLISH							2


#define 		BLMS_CONN_CREATE_RX_MAX_TRY_NUM					4
#define 		BLMS_CONN_UPDATE_BRX_MAX_TRY_NUM				4



#define 		BLMS_STACK_USED_TX_FIFO_NUM      				2

#define			CONN_CHANNEL_MAP								1


//#define			CONN_UPDATE_POSSIBLE							BIT(0)
#define			CONN_UPDATE_CMD									BIT(1)
#define			CONN_UPDATE_PENDING								BIT(2)
#define			CONN_UPDATE_NEARBY								BIT(3)
#define			CONN_UPDATE_SYNC								BIT(4)

#define         CONN_PHY_UPDATE_IND_CMD                         BIT(5)



#define			DATA_MARK_UPDATE_POTENTIAL						BIT(0)




multi_conn_fifo_t		blt_m_txfifo;
multi_conn_fifo_t		blt_s_txfifo;
u8						blt_m_txfifo_b[];
u8						blt_s_txfifo_b[];




_attribute_aligned_(4)
typedef struct {

	u8		tx_wptr;
	u8		tx_rptr;
	u8		tx_num;
	u8		conn_fifo_flag;

	u8		save_flg;
	u8		peer_last_sn;
	u8		local_sw_sn;
	u8		local_sw_nesn;


	u8		local_sn;
	u8		local_nesn;
	u8      conn_dma_tx_rptr;
	u8		peer_last_rfLen;

	u8		max_fifo_num;
	u8		rx_1st_pkt;
	u8      nack_flg;
	u8      conn_offset_next;		//we do not support too big interval, so winOffset u8  enough

	u8		role;
	u8      ll_enc_busy;
	u8		connState;			 // 0/Conn_Complete/Conn_Establish
	u8		conn_rx_num;  //rx number in a new interval   //TODO: all connection can share one

	u8      blt_tx_pkt_hold;
	u8		chn_idx;
	u8		conn_chn;
	u8		conn_update_param;


	u8		conn_channel_map;
	u8		conn_receive_packet;
	u8     	conn_established;
	u8		peer_adr_type;

	u8		conn_sca;
	u8		conn_receive_new_packet;
	u8 		conn_peer_terminate;
	u8 		conn_local_terminate;

	//0x20, 32

	u8		conn_terminate_reason;
	u8		conn_chn_hop;
	u8      conn_winsize_next;		//u8 is enough
	u8		conn_interval_next;		//we do not support too big interval, so u8  enough


	u8		conn_interval;		    //we do not support too big interval, so u8  enough
	u8		sync_timing;
	u8		sync_num;
	u8      encryption_evt;		//Event triggered by MainLoop


	u8		connect_evt;		//Event triggered by IRQ
	u8		disconn_evt;		//Event triggered by IRQ
	u8		conn_update_evt;	//Event triggered by IRQ
	u8		phy_update_evt;		//Event triggered by IRQ


	u8		encryption_tmp_st;
	u8      conn_update_phy;
	u16     conn_phy_inst_next;

#if(LL_FEATURE_ENABLE_CONNECTED_ISO)

	//TODO: remember to clear when connection terminate or complete
	u8		acl_cis_req_pendingMsk; // for master: CIS_REQ is wait to send
								 	// for slave:

  	u8		link_cis_handle;	//associated CIS connection handle, both master and slave will use, 0x20/0x21/0x22/0x23...
  								//u8 is enough, due to our special design
								//TODO, when connection terminate, clear it. so cis_handle is used to judge whether a CIS connection is associated
  	u8     	belongs2cigId;  	/* Which CIG_ID the ACL belongs to*/
  	u8 		rsvd;

  	u32		cis_req_accept_timeout;
#endif

	u16		conn_inst_next;
	u16		conn_map_inst_next;	    //update conn_param & update_map should separate, update map may delay to process due to BRX slot dropped
	u16		conn_latency;
	u16		conn_latency_next;
	u16		conn_timeout_next;     //Note: unit 10mS

	u16		connHandle;
	u16		conn_inst;
	u16		enc_ediv;       //EDIV

	//0x40, 64

	u16		conn_rx_repeatSingle_num;
	u16		conn_successive_miss;
	u32		conn_update_tick;
	u32		conn_update_pre_slotIndex;
	u32		conn_terminate_tick;
	u32 	conn_interval_tick;
	u32		conn_timeout;
	u32     conn_complete_tick;
	u32     conn_established_tick;  //no use

	//0x60, 96

	u32		conn_tick;
	u32		conn_access_code;
	u32		conn_crc;


	u32     conn_crc_revert; //revert crc24 init value
	u32 	ll_remoteFeature;

#if (BLUETOOTH_VER == BLUETOOTH_VER_5_2)
	u32 	ll_remoteFeature1; //for core5.2 featureSet
#endif

	u32		conn_inst_u32;


	u8		peer_adr[6];
	u8		conn_chn_map[5];
	u8		conn_chn_map_next[5];

	//0x88, 136

	u8		enc_random[8];  //RANDOM

	u32		enc_ivm;       //master IVm
	u8 		enc_skdm[8];   //master SKDm
	u32		enc_ivs;       //slave  IVs
	u8 		enc_skds[8];   //slave  SKDs

	//0xA8, 168

	u8		chn_tbl[40];
#if (BLMS_EARLY_CAL_MAP_TO_SAVE_TIME_EN)
	u8		chn_new_tbl[40];
#endif
	ble_crypt_para_t	crypt;   //40 Byte

	//0x120, 288

#if(LL_FEATURE_SUPPORT_CHANNEL_SELECTION_ALGORITHM2)
	u8 channel_used_num;
	u8 peer_chnSel;
	u16 channel_id;
	u8 conn_chnsel;
	u8 channel_new_used_num;
	u16 reserve;
#endif

	//0x128, 296

	u32		conn_pkt_rcvd;
	u32		conn_pkt_rcvd_no;

	//0x130, 304
	u8	rcvdLlOpcode;
	u8  sentLlOpcode;
	u8  connTermTxFifoWptr;
	u8	rsvd1; //aligned must

} st_llms_conn_t;

//extern _attribute_aligned_(4)	st_llms_conn_t	blms[];

extern _attribute_aligned_(4)	st_llms_conn_t	AA_blms[];   // AA_ just for debug
#define blms	AA_blms

extern u32 blt_llms_txFifoPtrKeep[3];

_attribute_aligned_(4)
typedef struct {
	u16		connEffectiveMaxRxOctets;
	u16		connEffectiveMaxTxOctets;
	u16 	connMaxRxOctets;
	u16 	connMaxTxOctets;
	u16		connRemoteMaxRxOctets;
	u16 	connRemoteMaxTxOctets;
	u16		supportedMaxRxOctets;
	u16		supportedMaxTxOctets;

	u8	 	connInitialMaxTxOctets;  //u8 is enough
	u8		connMaxTxRxOctets_req;
	u8		connRxDiff100;
	u8		connTxDiff100;
}ll_data_extension_t;
extern ll_data_extension_t  llms_bltData[];

extern st_llms_conn_t  *blms_pconn;
extern int				blms_conn_sel;



typedef int (*blms_LTK_req_callback_t)(u16 handle, u8* rand, u16 ediv);
//extern blms_LTK_req_callback_t blt_llms_ltk_request;

typedef bool (*ll_push_fifo_handler_t) (u16, u8 *);
extern  ll_push_fifo_handler_t				ll_push_tx_fifo_handler;
/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/









/******************************* Macro & Enumeration variables for User Begin ******************************************/
#define			BLM_CONN_HANDLE									BIT(7)
#define			BLS_CONN_HANDLE									BIT(6)

#define			BLMS_CONN_HANDLE								(BLM_CONN_HANDLE | BLS_CONN_HANDLE)


/******************************* Macro & Enumeration variables for User End ********************************************/





/******************************* Stack Interface Begin, user can not use!!! ********************************************/
int 		blms_connect_common(st_llms_conn_t *pc, rf_packet_connect_t * pInit);
int 		blms_start_common  (st_llms_conn_t *pc);
int 		blms_post_common   (st_llms_conn_t *pc);

u8  		blt_llms_get_tx_fifo_max_num (u16 connHandle);

void 		blt_llms_pushToHWfifo(void);
void 		blt_llms_saveTxfifoRptr(void);

bool 		blt_llms_pushTxfifo(u16 connHandle, u8 *p);
void 		blt_llms_push_fifo_hw(void);
void 		blt_llms_update_fifo_sw(void);
bool 		blt_llmsPushLlCtrlPkt(u16 connHandle, u8 opcode, u8*pkt);

bool		blt_llms_unknownRsp(u16 connHandle, u8 unknownType);
void		blt_llms_rejectInd(u16 connHandle, u8 opCode, u8 errCode, u8 extRejectInd);
int			blt_llms_main_loop_data (u16 connHandle, u8 *raw_pkt);

void 		blt_llms_procConnCreateConnParamUpdate(void);

void 		blt_llms_registerLtkReqEvtCb(blms_LTK_req_callback_t evtCbFunc);


int  		blt_llms_isConnectionEncrypted(u16 connHandle);

int 		blt_llms_startEncryption(u16 connHandle ,u16 ediv, u8* random, u8* ltk);

u8 			blt_llms_getConnState(u16 connHandle);

static inline u8 blt_llms_get_connEffectiveMaxTxOctets_by_connIdx(u16 conn_idx)
{
	#if (LL_FEATURE_ENABLE_LE_DATA_LENGTH_EXTENSION)
		return llms_bltData[conn_idx].connEffectiveMaxTxOctets;
	#else
		return 27;
	#endif
}

ble_sts_t   blc_hci_ltkRequestReply(u16 connHandle,  u8*ltk);
ble_sts_t   blc_hci_ltkRequestNegativeReply(u16 connHandle);
/******************************* Stack Interface End *******************************************************************/














/******************************* User Interface  Begin *****************************************************************/
int 		blc_llms_getCurrentConnectionNumber(void);   //master + slave connection number
int 		blc_llms_getCurrentMasterRoleNumber(void);   //master role number
int 		blc_llms_getCurrentSlaveRoleNumber(void);    //slave  role number

ble_sts_t 	blc_llms_setMaxConnectionNumber(int max_master_num, int max_slave_num);


u8  		blc_llms_getTxFifoNumber (u16 connHandle);

ble_sts_t 	blc_llms_disconnect (u16 connHandle, u8 reason);


#if (NEW_CODE_STRUCT)
static inline u32 blc_llms_getConnectionStartTick(u16 connHandle)
{
	return blms[connHandle & CONN_IDX_MASK].conn_complete_tick;  // CONN_IDX_MASK
}
#else
static inline u32 blc_llms_getConnectionStartTick(u16 connHandle)
{
	return blms[connHandle & 15].conn_complete_tick;  // CONN_IDX_MASK
}
#endif


ble_sts_t blc_llms_exchangeDataLength (u16 connHandle, u8 opcode, u16 maxTxOct );

/******************************* User Interface  End  ******************************************************************/

#endif /* LLMS_CONN_H_ */
