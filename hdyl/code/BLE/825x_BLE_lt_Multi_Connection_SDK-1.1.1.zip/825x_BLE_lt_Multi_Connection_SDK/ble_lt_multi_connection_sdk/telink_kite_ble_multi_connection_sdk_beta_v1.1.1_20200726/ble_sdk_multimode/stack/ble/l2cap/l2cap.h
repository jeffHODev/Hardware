/********************************************************************************************************
 * @file     l2cap.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     Sep. 18, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *           
 *			 The information contained herein is confidential and proprietary property of Telink 
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms 
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai) 
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in. 
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this 
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided. 
 *           
 *******************************************************************************************************/
#ifndef L2CAP_MS_H_
#define L2CAP_MS_H_

#include "stack/ble/llms/llms_slot.h"



/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/

// Response Timeout expired
#define L2CAP_RTX_TIMEOUT_MS             2000

#define NEXT_SIG_ID()                    ( ++l2capId == 0 ? l2capId = 1 : l2capId )


#define L2CAP_PKT_HANDLER_SIZE           6
 
 
// l2cap handler type
#define L2CAP_CMD_PKT_HANDLER            0
#define L2CAP_USER_CB_HANDLER            1

#define L2CAP_HEADER_LENGTH              0x0004
#define L2CAP_MTU_SIZE                   23

#define L2CAP_CONNECTION_PARAMETER_ACCEPTED        0x0000
#define L2CAP_CONNECTION_PARAMETER_REJECTED        0x0001









typedef struct
{
	u8 *rx_p;
	u8 *tx_p;
	u16 max_rx_size;

	u16 max_tx_size;
	u16 init_MTU;
}l2cap_buff_t;


/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/





/******************************* Macro & Enumeration variables for User Begin ******************************************/

typedef enum{
	CONN_PARAM_UPDATE_ACCEPT = 0x0000,
	CONN_PARAM_UPDATE_REJECT = 0x0001,
}conn_para_up_rsp;



/******************************* Macro & Enumeration variables for User End ********************************************/






/******************************* Stack Interface Begin, user can not use!!! ********************************************/
void blt_l2cap_para_pre_init(void);
u8* blt_l2cap_ms_pktPack(u16 connHandle, u8 * raw_pkt);
int blt_l2cap_pktHandler (u16 connHandle, u8 *raw_pkt);
ble_sts_t  blt_l2cap_pushData_2_controller (u16 connHandle, u16 cid, u8 *format, int format_len, u8 *pDate, int data_len);
u8   blt_UpdateParameter_request (u16 connHandle);
u8*  blt_l2cap_get_s_tx_buff(u16 connHandle);
/******************************* Stack Interface End *******************************************************************/






/******************************* User Interface  Begin *****************************************************************/


void blm_l2cap_initMtuBuffer(u8 *pMTU_m_rx_buff, u16 mtu_m_rx_size, u8 *pMTU_m_tx_buff,u16 mtu_m_tx_size);
void bls_l2cap_initMtuBuffer(u8 *pMTU_s_rx_buff, u16 mtu_s_rx_size, u8 *pMTU_s_tx_buff, u16 mtu_s_tx_size);

/*
 * called must after api blm_l2cap_initMtuBuffer()
 */
ble_sts_t  blm_l2cap_setRxMTUSize(u16 master_mtu_size);

/*
 * called must after api blm_l2cap_initMtuBuffer()
 */
ble_sts_t  bls_l2cap_setRxMTUSize(u16 slave_mtu_size);

void  		blc_l2cap_SendConnParamUpdateResponse(u16 connHandle, u8 req_id, conn_para_up_rsp result);

u8   bls_l2cap_requestConnParamUpdate (u16 connHandle, u16 min_interval, u16 max_interval, u16 latency, u16 timeout);
u8   bls_l2cap_setMinimalUpdateReqSendingTime_after_connCreate(u16 connHandle, int time_ms);

/******************************* User Interface  End  ******************************************************************/


#endif
