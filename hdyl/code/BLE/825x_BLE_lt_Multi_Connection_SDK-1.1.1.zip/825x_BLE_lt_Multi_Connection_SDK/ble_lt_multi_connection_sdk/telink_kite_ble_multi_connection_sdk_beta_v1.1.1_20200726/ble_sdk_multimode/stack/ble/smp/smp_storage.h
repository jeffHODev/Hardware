/********************************************************************************************************
 * @file     smp_storage.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     Jun. 28, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *           
 *			 The information contained herein is confidential and proprietary property of Telink 
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms 
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai) 
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in. 
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this 
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided. 
 *           
 *******************************************************************************************************/

#ifndef SMP_STORAGE_H_
#define SMP_STORAGE_H_

#include "stack/ble/llms/llms_device.h"
#include "stack/ble/llms/llms.h"

#include "stack/ble/smp/smp.h"
#include "stack/ble/llms/llms_slot.h"




/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/
#if (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M24_S3)
	#define 	SMP_MASTER_BONDING_DEVICE_MAX_NUM		28
	#define 	SMP_SLAVE_BONDING_DEVICE_MAX_NUM		4
#elif (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M16_S3)
	#define 	SMP_MASTER_BONDING_DEVICE_MAX_NUM		20
	#define 	SMP_SLAVE_BONDING_DEVICE_MAX_NUM		4
#elif (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M12_S2)
	#define 	SMP_MASTER_BONDING_DEVICE_MAX_NUM		16
	#define 	SMP_SLAVE_BONDING_DEVICE_MAX_NUM		4
#else
	#define 	SMP_MASTER_BONDING_DEVICE_MAX_NUM		8
	#define 	SMP_SLAVE_BONDING_DEVICE_MAX_NUM		4
#endif

#define 	SMP_PARAM_NV_UNIT						96

//smp storage area reaches alarm line 0 threshold
#define 	SMP_PARAM_CLEAN_INDEX_ALARM_LOW 		((SMP_PARAM_NV_MAX_LEN*3) >>2 ) //e.g.: 8k*3/4 -> 64*96
//smp storage area reaches alarm line 1 threshold
#define 	SMP_PARAM_CLEAN_INDEX_ALARM_HIGH 		(SMP_PARAM_NV_MAX_LEN - (SMP_PARAM_NV_UNIT<<1)) //e.g.: 8k -96*2 -> 84*96

#define		SMP_PARAM_NV_SEC_ADDR_START				(SMP_PARAM_NV_ADDR_START + SMP_PARAM_NV_MAX_LEN)
#define		SMP_PARAM_NV_SEC_ADDR_END				(SMP_PARAM_NV_SEC_ADDR_START + SMP_PARAM_NV_MAX_LEN - 1)



#define		FLAG_SMP_PARAM_SAVE_OLD					0x5A  // 0101 1010  old storage

														  // 10xx 1010  new storage,  xx: see "paring_sts_t" definition
#define		FLAG_SMP_PARAM_SAVE_BASE				0x8A  // 1000 1010
#define		FLAG_SMP_PARAM_SAVE_UNANTHEN			0x9A  // 1001 1010  new storage Unauthenticated_LTK
#define		FLAG_SMP_PARAM_SAVE_AUTHEN				0xAA  // 1010 1010  new storage Authenticated_LTK_Legacy_Paring
#define		FLAG_SMP_PARAM_SAVE_AUTHEN_SC			0xBA  // 1011 1010  new storage Authenticated_LTK_Secure_Connection

#define		FLAG_SMP_PARAM_SAVE_PENDING				0xBF  // 1011 1111
#define		FLAG_SMP_PARAM_SAVE_ERASE				0x00  //

#define 	FLAG_SMP_PARAM_MASK						0x0F  // 0000 1111
#define     FLAG_SMP_PARAM_VALID					0x0A  // 0000 1010
#define 	FLAG_SMP_PARING_STATUS_MASK				0x30  // 0011 1000


#define		FLAG_SMP_SECTOR_USE						0x3C
#define		FLAG_SMP_SECTOR_CLEAR					0x00

#define 	FLAG_SMP_PARAM_MASK						0x0F  // 0000 1111
#define     FLAG_SMP_PARAM_VALID					0x0A  // 0000 1010
#define 	FLAG_SMP_PARING_STATUS_MASK				0x30  // 0011 1000

#define		FLAG_CONN_ROLE_MASTER					BIT(7)
#define		MSK_SLAVE_DEV_IDX						0x07  // [2:0] slave device index

/*
 * smp parameter need save to flash.
 */
typedef struct {
	//0x00
	u8		flag;
	u8		role_dev_idx;  //[7]:1 for master, 0 for slave;   [2:0] slave device index

	u8		peer_addr_type;  //address used in link layer connection
	u8		peer_addr[6];

	u8		peer_id_adrType; //peer identity address information in key distribution, used to identify
	u8		peer_id_addr[6];

	//0x10
	u8 		local_peer_ltk[16];   //slave: local_ltk; master: peer_ltk

	//0x20
	u8 		encryt_key_size;
	u8		local_id_adrType;
	u8		local_id_addr[6];

	u8		random[8];  //8


	//0x30
	u8		peer_irk[16];

	//0x40
	u8		local_irk[16];        // local_csrk can be generated based on this key, to save flash area (delete this note at last, customers can not see it)

	//0x50
	u16 	ediv;       //2
	u8		rsvd[14];	//14  peer_csrk info address if needed(delete this note at last, customers can not see it)
}smp_param_save_t;


typedef struct {
#if (SMP_DATABASE_INFO_SOURCE == SMP_INFO_STORAGE_IN_FLASH)
	u16 master_bond_flash_idx[SMP_MASTER_BONDING_DEVICE_MAX_NUM];  				  //Attention: flash address offset here, 0xFFFF 64K max
	u16 slave_bond_flash_idx[SLAVE_DEV_MAX][SMP_SLAVE_BONDING_DEVICE_MAX_NUM];    //Attention: flash address offset here, 0xFFFF 64K max
#else
	//may be SRAM address if use other MCU store SMP information
#endif

	u8 paring_status[BLMS_MAX_CONN_NUM];
	u8 addrIndex[BLMS_MAX_CONN_NUM];   //different slave can not share this variable, master can share but not optimize
	u8 keyIndex[BLMS_MAX_CONN_NUM];    //different slave can not share this variable, master can share but not optimize

	u8 master_max_bonNum;
	u8 master_cur_bondNum;
	u8 master_curIndex;
	u8 isBond_fastSmp;

	u8 slave_max_bondNum;
	u8 slave_cur_bondNum[SLAVE_DEV_MAX];

	u8 index_update_method;
} smp_bond_device_t;

extern smp_bond_device_t  smpMStblBondDevice;

//#define BLMS_MAX_CONN_NUM  7
extern  int SMP_PARAM_NV_MAX_LEN;
extern	int smp_bond_device_flash_cfg_idx;

typedef enum {
	FLASH_OP_SUCCESS = 0,
	FLASH_OP_FAIL 	 = 1,
} flash_op_sts_t;

/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/




/******************************* Macro & Enumeration variables for User Begin ******************************************/

typedef enum {
	Index_Update_by_Pairing_Order = 0,     //default value
	Index_Update_by_Connect_Order = 1,
} index_updateMethod_t;

/******************************* Macro & Enumeration variables for User End ********************************************/




/*********************************** Stack Interface Begin, user can not use!!! **********************************/
void 			blt_smp_initBondingInfoFromFlash(void);
void			blt_smp_cleanBondingInfoStorage(void);

//Search
u32 	    	blt_smp_searchBondingDevice_by_PeerMacAddr(u8 isMasterRole,u8 slaveDevIdx, u8 peer_addr_type, u8* peer_addr);

//Get
static inline	u8	blt_smp_getBondingFlag_by_FlashAddr(u32 flash_addr) { return   *((u8*)flash_addr);}
u8          	blt_smp_getBondingIndex_by_FlashAddr(u8 isMaster, u8 slaveDevIdx, u32 flash_addr);

//Load
u32 			bls_smp_loadLTK_by_EdivRand(u8 slaveDevIdx, u16 ediv, u8* random, u8 *ltk); //for slave only
u32         	blt_smp_loadBondingInfoFromFlashByIndex(u8 isMaster, u8 slaveDevIdx, u8 index, smp_param_save_t* smp_param_load);
u32         	blt_smp_loadBondingInfoByAddr(u8 isMaster, u8 slaveDevIdx, u8 addr_type, u8* addr, smp_param_save_t* smp_param_load);

//Delete
int	        	blt_smp_deleteBondingInfo_by_Index(u8 isMaster, u8 slaveDevIdx, u8 index);
int	        	blt_smp_deleteBondingInfo_by_PeerMacAddress(u8 isMaster, u8 slaveDevIdx, u8 peer_addr_type, u8* peer_addr);
void 			blt_smp_procBondingInfoIndexAlarm(bool isAllRolesIdle);

//Update
u32         	blt_smp_updateBondingInfoToNearestByIndex(u8 isMaster, u8 slaveDevIdx, u8 index);

//Save
int         	blt_smp_saveBondingInfoToFlash(u8 isMaster, u8 slaveDevIdx, smp_param_save_t* save_param);

/************************************ User Interface  End  ********************************************************/




/************************************ User Interface  Begin  ******************************************************/

void 			blc_smp_configParingSecurityInfoStorageAddressAndSize (int address, int size_byte);  //address and size must be 4K aligned
void 			blc_smp_setBondingDeviceMaxNumber ( int peer_slave_max, int peer_master_max);
u32 			blc_smp_getBondingInfoCurStartAddr(void);
//Search
// This API is for master only, to search if current slave device is already paired with master
u32 			blc_smp_searchBondingSlaveDevice_by_PeerMacAddress( u8 peer_addr_type, u8* peer_addr);

//Delete
int				blc_smp_deleteBondingSlaveInfo_by_PeerMacAddress(u8 peer_addr_type, u8* peer_addr);
void			blc_smp_setBondingInfoIndexUpdateMethod(index_updateMethod_t method);
void			blc_smp_eraseAllBondingInfo(void);

static inline	bool blc_smp_isBondingInfoStorageLowAlarmed(void)
{
	return (smp_bond_device_flash_cfg_idx >= SMP_PARAM_CLEAN_INDEX_ALARM_LOW);
}

/************************************ User Interface  End  ********************************************************/




#endif /* SMP_STORAGE_H_ */
