/********************************************************************************************************
 * @file     att.h 
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     Sep. 18, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *           
 *			 The information contained herein is confidential and proprietary property of Telink 
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms 
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai) 
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in. 
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this 
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided. 
 *           
 *******************************************************************************************************/

#pragma once

#include "tl_common.h"
#include "stack/ble/blt_config.h"
#include "stack/ble/ble_common.h"
#include "stack/ble/l2cap/l2cap.h"
#include "gatt.h"

/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/

typedef int (*att_readwrite_callback_t)(u16 connHandle, void* p);
typedef struct attribute
{
  u16  attNum;
  u8   perm;
  u8   uuidLen;
  u32  attrLen;    //4 bytes aligned
  u8* uuid;
  u8* pAttrValue;
  att_readwrite_callback_t w;
  att_readwrite_callback_t r;
} attribute_t;


/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/








/******************************* Macro & Enumeration variables for User Begin ******************************************/
#define ATT_MTU_SIZE                        23  //!< Minimum ATT MTU size
#define ATT_MAX_ATTR_HANDLE                 0xFFFF
#define ATT_16BIT_UUID_LEN                  2
#define ATT_128BIT_UUID_LEN                 16
#define L2CAP_RESERVED_LEN                  14
#define OPCODE_SIZE                         1
#define L2CAP_PAYLOAD_OFFSET                (L2CAP_RESERVED_LEN + OPCODE_SIZE)
#define ATT_HANDLE_START                    0x0001
#define ATT_HANDLE_END                      0xFFFF


typedef struct
{
  u8 len;                    //!< Length of UUID
  u8 uuid[16];               //!< UUID
} uuid_t;

// Error Response
typedef struct
{
    u8 reqOpcodeInErr; //!< The request that generated this error response
    u8 errCode;   //!< The reason why the request has generated an error response
    u16 attHandleInErr;   //!< The attribute handle that generated this error response
} errorRsp_t;

// Exchange MTU Request
typedef struct
{
    u16 clientRxMTU; //!< Attribute client receive MTU size 
} exchangeMTUReq_t;

// Exchange MTU Response
typedef struct
{
    u16 serverRxMTU; //!< Attribute server receive MTU size
} exchangeMTURsp_t;

// Find Information Request
typedef struct
{
    u16 startingHandle;       //!< First requested handle number
    u16 endingHandle;         //!< Last requested handle number
} findInformationReq_t;

// Handle(s) and 16-bit Bluetooth UUID(s)
typedef struct
{
    u16 handle;                //!< Handle
    u8 uuid[ATT_16BIT_UUID_LEN]; //!< 16 bit UUID
} handleBtUUID_t;

// Handle(s) and 128-bit UUID(s)
typedef struct
{
    u16 handle;             //!< Handle
    u8 uuid[ATT_128BIT_UUID_LEN]; //!< 128 bit UUID
} handleUUID_t;

// Find Information Response
typedef struct
{
    u8 format;       //!< Format of information
    u8 infoNum;      //!< information num
    u8 info[1];      //!< information
} findInformationRsp_t;

// Find By Type Value Request
typedef struct
{
  u16  startingHandle;          //!< First requested handle number 
  u16  endingHandle;            //!< Last requested handle number
  u16  uuid;                    //!< UUID to find
  u8   len;                     //!< Length of value
  u8   value[1];   //!< Attribute value to find
} findByTypeValueReq_t;

// Handles Infomation list element
typedef struct
{
  u8 handle;         //!< Found attribute handle
  u8 groupEndHandle; //!< Group end handle
} handleInfo_t;

// Find By Type Value Response
typedef struct
{
  u8 handleInfoNum;                                       //!< Number of handles information below
  handleInfo_t handleInfo[1] ; //!< A list of 1 or more Handle Informations
} findByTypeValueRsp_t;

// Read By Type Request
typedef struct
{
  u16 startingHandle; //!< First requested handle number
  u16 endingHandle;   //!< Last requested handle number
  uuid_t attrType;    //!< 2 or 16 octet UUID
} readByTypeReq_t;

// Read By Type Response
typedef struct
{
  u8 numData;                  //!< Number of attribute data list item
  u8 len;                      //!< The size of each attribute handle-value pair
  u8 data[1];     //!< Attribute Data List
} readByTypeRsp_t;

// Read Request
typedef struct
{
  u16 handle;               //!< The handle of the attribute to be read
} readReq_t;

// Read Response
typedef struct
{
  u8 len;                   //!< Length of value
  u8 attrValue[1];          //!< Value of the attribute with the handle given
} readRsp_t;

// Read Blob Req
typedef struct
{
  u16 handle; //!< The handle of the attribute to be read
  u16 offset; //!< The offset of the first octet to be read
} readBlobReq_t;

// Read Blob Response
typedef struct
{
  u8 len;      //!< Length of value
  u8 attrValue[1]; //!< Part of the value of the attribute with the handle given
} readBlobRsp_t;

// Read Multiple Request
typedef struct
{
  u8  numHandles; //!< Number of attribute handles
  u16 handle[1];  //!< A set of two or more attribute handles
} readMultipleReq_t;

// Read Multiple Response
typedef struct
{
  u8 len;       //!< Length of values
  u8 values[1]; //!< A set of two or more values
} readMultiRsp_t;

// Read By Group Type Request
typedef struct
{
  u16 startingHandle; //!< First requested handle number (must be first field)
  u16 endingHandle;   //!< Last requested handle number
  uuid_t attrType;     //!< 2 or 16 octet UUID
} readByGroupTypeReq_t;

// Read By Group Type Response
typedef struct
{
  u8 grpNum;                  //!< The number of attributes in this group
  u8 len;                      //!< Length of each attribute handle
  u8 data[1];                 //!< Attribute Data
} readByGroupTypeRsp_t;

// Write Request
typedef struct
{
  u16 handle;                            //!< The handle of the attribute to be written (must be first field)
  u8 len;                                //!< Length of value
  u8 value[1];            //!< The value to be written to the attribute
} writeReq_t;

// Write Command
typedef struct
{
  u16 handle;                         //!< The handle of the attribute to be written (must be first field)
  u8 len;                             //!< Length of value
  u8 value[1];         //!< The value to be written to the attribute
  u8 sig;                             //!< the sig flag
} writeCmd_t;

// Prepare Write Request
typedef struct
{
  u16 handle;                 //!< Handle of the attribute to be written (must be first field)
  u16 offset;                 //!< Offset of the first octet to be written
  u8 len;                     //!< Length of value
  u8 value[1]; //!< Part of the value of the attribute to be written
} prepareWriteReq_t;

// Prepare Write Response
typedef struct
{
  u16 handle;                       //!< The handle of the attribute to be written
  u16 offset;                       //!< The offset of the first octet to be written
  u8 len;                           //!< Length of value
  u8 value[1];              //!< The value of the attribute to be written
} prepareWriteRsp_t;

// Execute Write Request
typedef struct
{
  u8 flags;   //!< 0x00 - cancel all prepared writes 0x01 - immediately write all pending prepared values
} executeWriteReq_t;

// Handle Value Notification
typedef struct
{
  u16 handle;               //!< The handle of the attribute
  u8 len;                   //!< Length of value
  u8 value[1];              //!< The current value of the attribute
} handleValueNoti_t;

// Handle Value Indication
typedef struct
{
  u16 handle;               //!< The handle of the attribute
  u8 len;                   //!< Length of value
  u8 value[1];              //!< The current value of the attribute
} handleValueInd_t;

typedef union attOpCode{
    struct{
        u8 method:6;
        u8 cmdFlag:1;
        u8 authSigFlag:1;
    }bitField;
    u8 byte;
}attOpCode_t;

// ATT_PERMISSIONS_BITMAPS GAP ATT Attribute Access Permissions Bit Fields
// (See the Core_v5.0(Vol 3/Part C/10.3.1/Table 10.2) for more information)
#define ATT_PERMISSIONS_AUTHOR				 0x10 //Attribute access(Read & Write) requires Authorization
#define ATT_PERMISSIONS_ENCRYPT				 0x20 //Attribute access(Read & Write) requires Encryption
#define ATT_PERMISSIONS_AUTHEN				 0x40 //Attribute access(Read & Write) requires Authentication(MITM protection)
#define ATT_PERMISSIONS_SECURE_CONN			 0x80 //Attribute access(Read & Write) requires Secure_Connection
#define ATT_PERMISSIONS_SECURITY			 (ATT_PERMISSIONS_AUTHOR | ATT_PERMISSIONS_ENCRYPT | ATT_PERMISSIONS_AUTHEN | ATT_PERMISSIONS_SECURE_CONN)


// user can choose permission below
#define ATT_PERMISSIONS_READ                 0x01 //!< Attribute is Readable
#define ATT_PERMISSIONS_WRITE                0x02 //!< Attribute is Writable
#define ATT_PERMISSIONS_RDWR	             (ATT_PERMISSIONS_READ | ATT_PERMISSIONS_WRITE)   //!< Attribute is Readable & Writable

#define ATT_PERMISSIONS_ENCRYPT_READ         (ATT_PERMISSIONS_READ  | ATT_PERMISSIONS_ENCRYPT) 		//!< Read requires Encryption
#define ATT_PERMISSIONS_ENCRYPT_WRITE        (ATT_PERMISSIONS_WRITE | ATT_PERMISSIONS_ENCRYPT) 		//!< Write requires Encryption
#define ATT_PERMISSIONS_ENCRYPT_RDWR         (ATT_PERMISSIONS_RDWR  | ATT_PERMISSIONS_ENCRYPT) 		//!< Read & Write requires Encryption

#define ATT_PERMISSIONS_AUTHEN_READ          (ATT_PERMISSIONS_READ  | ATT_PERMISSIONS_ENCRYPT | ATT_PERMISSIONS_AUTHEN) 		//!< Read requires Authentication
#define ATT_PERMISSIONS_AUTHEN_WRITE         (ATT_PERMISSIONS_WRITE | ATT_PERMISSIONS_ENCRYPT | ATT_PERMISSIONS_AUTHEN) 		//!< Write requires Authentication
#define ATT_PERMISSIONS_AUTHEN_RDWR          (ATT_PERMISSIONS_RDWR  | ATT_PERMISSIONS_ENCRYPT | ATT_PERMISSIONS_AUTHEN) 		//!< Read & Write requires Authentication

#define ATT_PERMISSIONS_SECURE_CONN_READ	 (ATT_PERMISSIONS_READ  | ATT_PERMISSIONS_SECURE_CONN | ATT_PERMISSIONS_ENCRYPT | ATT_PERMISSIONS_AUTHEN)   //!< Read requires Secure_Connection
#define ATT_PERMISSIONS_SECURE_CONN_WRITE    (ATT_PERMISSIONS_WRITE | ATT_PERMISSIONS_SECURE_CONN | ATT_PERMISSIONS_ENCRYPT | ATT_PERMISSIONS_AUTHEN)  //!< Write requires Secure_Connection
#define ATT_PERMISSIONS_SECURE_CONN_RDWR	 (ATT_PERMISSIONS_RDWR  | ATT_PERMISSIONS_SECURE_CONN | ATT_PERMISSIONS_ENCRYPT | ATT_PERMISSIONS_AUTHEN)   //!< Read & Write requires Secure_Connection


#define ATT_PERMISSIONS_AUTHOR_READ          (ATT_PERMISSIONS_READ | ATT_PERMISSIONS_AUTHOR) 		//!< Read requires Authorization
#define ATT_PERMISSIONS_AUTHOR_WRITE         (ATT_PERMISSIONS_WRITE | ATT_PERMISSIONS_AUTHEN) 		//!< Write requires Authorization
#define ATT_PERMISSIONS_AUTHOR_RDWR          (ATT_PERMISSIONS_RDWR | ATT_PERMISSIONS_AUTHOR) 		//!< Read & Write requires Authorization


// GATT_Characteristic_Property GATT characteristic properties
#define CHAR_PROP_BROADCAST              0x01 //!< permit broadcasts of the Characteristic Value
#define CHAR_PROP_READ                   0x02 //!< permit reads of the Characteristic Value
#define CHAR_PROP_WRITE_WITHOUT_RSP      0x04 //!< Permit writes of the Characteristic Value without response
#define CHAR_PROP_WRITE                  0x08 //!< Permit writes of the Characteristic Value with response
#define CHAR_PROP_NOTIFY                 0x10 //!< Permit notifications of a Characteristic Value without acknowledgement
#define CHAR_PROP_INDICATE               0x20 //!< Permit indications of a Characteristic Value with acknowledgement
#define CHAR_PROP_AUTHEN                 0x40 //!< permit signed writes to the Characteristic Value
#define CHAR_PROP_EXTENDED               0x80 //!< additional characteristic properties are defined

/******************************* Macro & Enumeration variables for User End ********************************************/









/******************************* Stack Interface Begin, user can not use!!! ********************************************/
u8 * bls_att_l2capAttCmdHandler(u16 connHandle, u8 * p);
/******************************* Stack Interface End *******************************************************************/






/******************************* User Interface  Begin *****************************************************************/
void		 bls_att_setAttributeTable (u8 *p);
ble_sts_t	 blc_att_requestMtuSizeExchange (u16 connHandle, u16 mtu_size);

		// 0x04: ATT_OP_FIND_INFO_REQ
void 	att_req_find_info(u8 *dat, u16 start_attHandle, u16 end_attHandle);
		// 0x06: ATT_OP_FIND_BY_TYPE_VALUE_REQ
void 	att_req_find_by_type (u8 *dat, u16 start_attHandle, u16 end_attHandle, u8 *uuid, u8* attr_value, int len);
		// 0x08: ATT_OP_READ_BY_TYPE_REQ
void 	att_req_read_by_type (u8 *dat, u16 start_attHandle, u16 end_attHandle, u8 *uuid, int uuid_len);
		// 0x0a: ATT_OP_READ_REQ
void 	att_req_read (u8 *dat, u16 attHandle);
		// 0x0c: ATT_OP_READ_BLOB_REQ
//void 	att_req_read_blob (u8 *dat, u16 attHandle, u16 offset);
		// 0x10: ATT_OP_READ_BY_GROUP_TYPE_REQ
void 	att_req_read_by_group_type (u8 *dat, u16 start_attHandle, u16 end_attHandle, u8 *uuid, int uuid_len);
		// 0x12: ATT_OP_WRITE_REQ
//void 	att_req_write (u8 *dat, u16 attHandle, u8 *buf, int len);
		// 0x52: ATT_OP_WRITE_CMD
//void 	att_req_write_cmd (u8 *dat, u16 attHandle, u8 *buf, int len);

/******************************* User Interface  End  ******************************************************************/





