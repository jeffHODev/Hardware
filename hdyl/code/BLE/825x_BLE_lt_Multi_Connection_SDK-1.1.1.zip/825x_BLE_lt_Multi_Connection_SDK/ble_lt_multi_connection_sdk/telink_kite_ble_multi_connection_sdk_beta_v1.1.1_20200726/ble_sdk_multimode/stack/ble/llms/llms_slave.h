/********************************************************************************************************
 * @file     llms_slave.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     May. 22, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/

#ifndef LLMS_SLAVE_H_
#define LLMS_SLAVE_H_

#include "stack/ble/llms/llms_config.h"


/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/
#ifndef			SLAVE_SLOT_FINE_TUNE_EN
#define			SLAVE_SLOT_FINE_TUNE_EN							1   // enable:  make sure slave sync master timing
#endif																// disable: slave will disconnect for long time; can use this to see BRX early set timing



#define			SLAVE_SYNC_CONN_CREATE							BIT(0)
#define			SLAVE_SYNC_CONN_UPDATE							BIT(1)


#define			BRX_EARLY_SET_TICK_SYNC							(200 * CLOCK_16M_SYS_TIMER_CLK_1US)
#define			BRX_EARLY_SET_TICK_COMMON						(150 * CLOCK_16M_SYS_TIMER_CLK_1US)


_attribute_aligned_(4)
typedef struct {
	u32		connExpectTime;
	u32		conn_start_time;
	u32 	conn_tolerance_time;
	u32 	early_set_time;
	u32		conn_duration;

	u32		tick_1st_rx;

	u32		tick_fine_tune;

} st_lls_conn_t;

extern	_attribute_aligned_(4)	st_lls_conn_t	blmsSlave[];
extern	st_lls_conn_t	*bls_pconn;
extern	int				bls_conn_sel;




typedef int (*ll_acl_slave_terminate_irq_callback_t)(void);

/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/




/******************************* Macro & Enumeration variables for User Begin ******************************************/


/******************************* Macro & Enumeration variables for User End ********************************************/





/******************************* Stack Interface Begin, user can not use!!! ********************************************/
int 	blms_s_connect (rf_packet_connect_t * pInit);
int 	blms_brx_start(void);
int 	blms_brx_post(void);

int		blt_llms_set_interval_level (u8 conn_idx, u16 conn_interval);

void 	blt_ll_registerAclSlaveTerminateIrqCb(ll_acl_slave_terminate_irq_callback_t  cb);

/******************************* Stack Interface End *******************************************************************/






/******************************* User Interface  Begin *****************************************************************/



/******************************* User Interface  End  ******************************************************************/



#endif /* LLMS_SLAVE_H_ */
