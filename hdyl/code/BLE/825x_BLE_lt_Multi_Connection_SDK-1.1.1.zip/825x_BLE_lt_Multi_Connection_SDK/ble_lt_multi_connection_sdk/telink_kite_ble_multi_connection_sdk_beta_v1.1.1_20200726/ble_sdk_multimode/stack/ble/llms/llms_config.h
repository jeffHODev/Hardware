/********************************************************************************************************
 * @file     llms_config.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     March. 02, 2020
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/

#ifndef LLMS_CONFIG_H_
#define LLMS_CONFIG_H_




/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/

#define			CONN_MAX_NUM_M1_S1									0
#define			CONN_MAX_NUM_M2_S2									1
#define			CONN_MAX_NUM_M4_S3									2
#define			CONN_MAX_NUM_M4_S0									3
#define			CONN_MAX_NUM_M0_S3									4

#define         CONN_MAX_NUM_M12_S2                                 5
#define         CONN_MAX_NUM_M16_S3                                 6
#define         CONN_MAX_NUM_M24_S3                                 7

#ifndef			CONN_MAX_NUM_CONFIG
#define			CONN_MAX_NUM_CONFIG									CONN_MAX_NUM_M4_S3
#endif


#if (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M1_S1)
	// connHandle:
	// Master:	0x80  Slave:  0x41
	#define			BLMS_MAX_CONN_NUM								2
	#define			BLMS_MAX_CONN_MASTER_NUM						1
	#define			BLMS_MAX_CONN_SLAVE_NUM							1


	#define			CONN_IDX_MASTER0								0
	#define			CONN_IDX_SLAVE0									1

    #define         BLMS_PM_ENABLE									1   //Now only M1S1 support PM
	#define			SLAVE_SLOT_FINE_TUNE_EN							0	//When PM enable, slave fine tune effect not enough
	#define			SLAVE_SLOT_DYNAMIC_ADJUST_EN					1   //When PM enable, slave use slot dynamic adjust
#elif (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M2_S2)
	// connHandle:
	// Master:	0x80/0x81   Slave:  0x42/0x43
	#define			BLMS_MAX_CONN_NUM								4
	#define			BLMS_MAX_CONN_MASTER_NUM						2
	#define			BLMS_MAX_CONN_SLAVE_NUM							2


	#define			CONN_IDX_MASTER0								0
	#define			CONN_IDX_SLAVE0									2

#elif (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M4_S3)
	// connHandle:
	// Master:	0x80/0x81/0x82/0x83   Slave:  0x44/0x45/0x46
	#define			BLMS_MAX_CONN_NUM								7
	#define			BLMS_MAX_CONN_MASTER_NUM						4
	#define			BLMS_MAX_CONN_SLAVE_NUM							3


	#define			CONN_IDX_MASTER0								0
	#define			CONN_IDX_SLAVE0									4

#elif (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M4_S0)
	// connHandle:
	// Master:	0x80/0x81/0x82/0x83
	#define			BLMS_MAX_CONN_NUM								4
	#define			BLMS_MAX_CONN_MASTER_NUM						4
	#define			BLMS_MAX_CONN_SLAVE_NUM							0


	#define			CONN_IDX_MASTER0								0
	#define			CONN_IDX_SLAVE0									4

	#define			BLMS_CONN_SLAVE_EN								0

#elif (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M0_S3)
	// connHandle:
	// Slave:	0x40/0x41/0x42
	#define			BLMS_MAX_CONN_NUM								3
	#define			BLMS_MAX_CONN_MASTER_NUM						0
	#define			BLMS_MAX_CONN_SLAVE_NUM							3


	#define			CONN_IDX_MASTER0								0
	#define			CONN_IDX_SLAVE0									0

	#define			BLMS_CONN_MASTER_EN								0

#elif (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M12_S2)

	#define        NEW_CODE_STRUCT                                 1
	// connHandle:
	// Master:	0x80/0x81/0x82/0x83.../0x8c   Slave:  0x4c/0x4d/0x4e
	//BIT(7):master; BIT(6):slave; bit5~bit0:conn_idx--0~63  (0~15master;16~18slave)
	#define			BLMS_MAX_CONN_NUM								14
	#define			BLMS_MAX_CONN_MASTER_NUM						12
	#define			BLMS_MAX_CONN_SLAVE_NUM							2


	#define			CONN_IDX_MASTER0								0
	#define			CONN_IDX_SLAVE0									12

#elif (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M16_S3)

	#define        NEW_CODE_STRUCT                                 1
	// connHandle:
	// Master:	0x80/0x81/0x82/0x83.../0x8f   Slave:  0x50/0x51/0x52
	//BIT(7):master; BIT(6):slave; bit5~bit0:conn_idx--0~63  (0~15master;16~18slave)
	#define			BLMS_MAX_CONN_NUM								19
	#define			BLMS_MAX_CONN_MASTER_NUM						16
	#define			BLMS_MAX_CONN_SLAVE_NUM							3


	#define			CONN_IDX_MASTER0								0
	#define			CONN_IDX_SLAVE0									16
#elif (CONN_MAX_NUM_CONFIG == CONN_MAX_NUM_M24_S3)

	#define        NEW_CODE_STRUCT                                 1
	// connHandle:
	// Master:	0x80/0x81/0x82/0x83.../0x98   Slave:  0x58/0x59/0x5a
	//BIT(7):master; BIT(6):slave; bit5~bit0:conn_idx--0~63  (0~15master;16~18slave)
	#define			BLMS_MAX_CONN_NUM								27
	#define			BLMS_MAX_CONN_MASTER_NUM						24
	#define			BLMS_MAX_CONN_SLAVE_NUM							3


	#define			CONN_IDX_MASTER0								0
	#define			CONN_IDX_SLAVE0									24
#endif


#ifndef        NEW_CODE_STRUCT
#define        NEW_CODE_STRUCT                                      0
#endif



#ifndef			BLMS_CONN_MASTER_EN
#define			BLMS_CONN_MASTER_EN									1
#endif

#ifndef			BLMS_CONN_SLAVE_EN
#define			BLMS_CONN_SLAVE_EN									1
#endif

/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/



#endif /* LLMS_CONFIG_H_ */
