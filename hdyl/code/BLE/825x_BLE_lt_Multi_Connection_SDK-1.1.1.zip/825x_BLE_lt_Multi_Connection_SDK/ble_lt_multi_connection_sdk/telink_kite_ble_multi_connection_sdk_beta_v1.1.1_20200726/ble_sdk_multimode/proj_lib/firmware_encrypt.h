/*
 * encrypt.h
 *
 *  Created on: 2019-3-27
 *      Author: Administrator
 */

#ifndef ENCRYPT_H_
#define ENCRYPT_H_

void firmware_encrypt_based_on_uid(unsigned char* uid,unsigned char* ciphertext);

#endif /* ENCRYPT_H_ */
