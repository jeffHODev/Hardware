/********************************************************************************************************
 * @file     llms_device.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     May. 22, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/

#ifndef LLMS_DEVICE_H_
#define LLMS_DEVICE_H_

#ifndef			BLMS_MULTI_LOCAL_MAC_EN
#define			BLMS_MULTI_LOCAL_MAC_EN							0
#endif

#if (BLMS_MULTI_LOCAL_MAC_EN)
	#define			SLAVE_DEV_MAX								3
#else
	#define			SLAVE_DEV_MAX								1
#endif

#ifndef        BLMS_MULTI_CONN_MULTI_DLE_EN
#define        BLMS_MULTI_CONN_MULTI_DLE_EN                     1
#endif

typedef enum {
	MASTER_DEVICE_INDEX_0     = 0,

	SLAVE_DEVICE_INDEX_0      = 0,
	SLAVE_DEVICE_INDEX_1      = 1,
	SLAVE_DEVICE_INDEX_2      = 2
}local_dev_ind_t;   //local device index


/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/



/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/




/******************************* Macro & Enumeration variables for User Begin ******************************************/



/******************************* Macro & Enumeration variables for User End ********************************************/





/******************************* Stack Interface Begin, user can not use!!! ********************************************/



/******************************* Stack Interface End *******************************************************************/




/******************************* User Interface  Begin *****************************************************************/



/******************************* User Interface  End  ******************************************************************/

#endif /* LLMS_DEVICE_H_ */
