/********************************************************************************************************
 * @file     llms_pm.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     Dec. 16, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/

#ifndef LLMS_PM_H_
#define LLMS_PM_H_

#include "tl_common.h"
#include "drivers.h"
#include "llms_device.h"




/****************** Macro & Enumeration & Structure Definition for Stack, user can not use!!!!  ******************/
#ifndef			BLMS_PM_ENABLE
#define			BLMS_PM_ENABLE									0
#endif

#define			BLMS_PM_ALLOWED_TIMING_MARGIN				    (625*CLOCK_16M_SYS_TIMER_CLK_1US)


typedef 	int (*llms_module_pm_callback_t)(void);


////////////////// Power Management ///////////////////////
typedef enum {
	PM_SUSPEND_DISABLE      = 0,
	PM_SUSPEND_ADV 		    = BIT(0),
	PM_SUSPEND_SCAN 		= BIT(1),
	PM_SUSPEND_SLAVE 		= BIT(2),
	PM_SUSPEND_MASTER 		= BIT(3),
}pm_mask_t;


#if (NEW_CODE_STRUCT)
_attribute_aligned_(4)
typedef struct {
	u8		wakeup_src;
	u8		suspend_allowed;
	u8		next_slot_task;
	u8		pm_start_update_slave;

	u8		pm_start_update_master;
	u8		rsvd[3];

	u32     suspend_mask;  ///u16 --> u32

	u16     rsvd1;
	u16		pm_border_flag;
	u16		tolerance_max_us;
	u16 	pmDisable_max_us;

	u32		master_error_us;
	u32	    slave_error_us;
	u32		sleep_tick;
	u32		next_slot_tick;
	u32     current_wakeup_tick; //The system wake-up tick of the actual transfer of the cpu_sleep_wakeup function.

}st_llms_pm_t;
#else
_attribute_aligned_(4)
typedef struct {
	u8		wakeup_src;
	u8		suspend_allowed;
	u8		next_slot_task;
	u8		pm_start_update_slave;

	u8		pm_start_update_master;
	u8		rsvd[3];

	u16		suspend_mask;
	u16		pm_border_flag;
	u16		tolerance_max_us;
	u16 	pmDisable_max_us;

	u32		master_error_us;
	u32	    slave_error_us;
	u32		sleep_tick;
	u32		next_slot_tick;
	u32     current_wakeup_tick; //The system wake-up tick of the actual transfer of the cpu_sleep_wakeup function.

}st_llms_pm_t;

#endif
extern st_llms_pm_t  blmsPm;
/************************** Macro & Enumeration & Structure Definition for Stack End  ****************************/









/******************************* Macro & Enumeration variables for User Begin ************************************/




/******************************* Macro & Enumeration variables for User End ************************************/








/*********************************** Stack Interface Begin, user can not use!!! **********************************/





/*********************************** Stack Interface End *********************************************************/










/************************************ User Interface  Begin  ******************************************************/
void 	blc_llms_initPowerManagement_module(void);

void 	blc_pm_setSuspendMask (pm_mask_t mask);

void	blc_pm_setWakeupSource (SleepWakeupSrc_TypeDef wakeup_src);

u32 	blc_pm_getSystemWakeupTick(void);

/************************************ User Interface  End  ********************************************************/

#endif /* LLMS_PM_H_ */


