/********************************************************************************************************
 * @file     ble.h 
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     Sep. 18, 2015
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *           
 *			 The information contained herein is confidential and proprietary property of Telink 
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms 
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai) 
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in. 
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this 
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided. 
 *           
 *******************************************************************************************************/

#ifndef BLE_H_
#define BLE_H_


#include "blt_config.h"
#include "ble_common.h"


#include "l2cap/l2cap.h"



#include "attr/att.h"
#include "attr/gatt.h"
#include "attr/gatt_uuid.h"


#include "smp/smp.h"
#include "smp/smp_storage.h"
#include "smp/smp_const.h"

#include "gap/gap.h"
#include "gap/gap_event.h"

#include "crypt/aes_ccm.h"
#include "crypt/le_crypto.h"
#include "crypt/aes/aes_att.h"

#include "hci/hci.h"
#include "hci/hci_const.h"
#include "hci/hci_cmd.h"
#include "hci/hci_event.h"
#include "hci/usb_desc.h"

#include "service/ble_ll_ota.h"
#include "service/device_information.h"
#include "service/hids.h"



#if (LL_MULTI_MASTER_MULTI_SLAVE_ENABLE)
	#include "llms/llms.h"
	#include "llms/llms_config.h"
	#include "llms/llms_slot.h"
	#include "llms/llms_adv.h"
	#include "llms/llms_scan.h"
	#include "llms/llms_init.h"
	#include "llms/llms_slave.h"
	#include "llms/llms_master.h"
	#include "llms/llms_conn.h"
	#include "llms/llms_pm.h"
#endif



#include "whitelist/whitelist.h"
#include "csa/csa.h"
#include "phy/phy.h"
#include "phy/phy_test.h"




volatile void  smemset(register char * dest,register int val,register unsigned int len);
volatile void * smemcpy(register char * out, register char * in, register unsigned int len);



#endif /* BLE_H_ */
