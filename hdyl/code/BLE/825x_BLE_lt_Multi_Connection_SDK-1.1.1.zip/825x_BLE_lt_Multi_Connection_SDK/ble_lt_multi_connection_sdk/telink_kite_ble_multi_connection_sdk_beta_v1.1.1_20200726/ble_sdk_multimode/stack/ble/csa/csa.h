/********************************************************************************************************
 * @file     csa.h
 *
 * @brief    for TLSR chips
 *
 * @author	 BLE Group
 * @date     July. 4, 2019
 *
 * @par      Copyright (c) Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *			 The information contained herein is confidential and proprietary property of Telink
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/

#ifndef CSA_H_
#define CSA_H_

#if (LL_FEATURE_ENABLE_CHANNEL_SELECTION_ALGORITHM2)


/******************************* Macro & Enumeration variables for User Begin ******************************************/
//See the Core_v5.0(Vol 6/Part B/4.5.8, "Data Channel Index Selection") for more information.
typedef enum {
	CHANNAL_SELECTION_ALGORITHM_1      	=	0x00,
	CHANNAL_SELECTION_ALGORITHM_2      	=	0x01,
} channel_algorithm_t;
/******************************* Macro & Enumeration variables for User End ********************************************/


/******************************* Macro & Enumeration & Structure Definition for Stack Begin, user can not use!!!!  *****/
extern channel_algorithm_t local_chsel;
/******************************* Macro & Enumeration & Structure Definition for Stack End ******************************/


/******************************* Stack Interface Begin, user can not use!!! ********************************************/
typedef u8 (*ll_chn_index_calc_callback_t)(u8*, u16, u16, u8*, u8);
extern ll_chn_index_calc_callback_t	ll_chn_index_calc_cb;

u8 blt_csa2_calculateRemapping_table(u8 chm[5], u8 *remap_tbl, u8 *channel_used_num);
u8 blt_csa2_calculateChannel_index(u8 chm[5], u16 event_cntr, u16 channel_id, u8 *remap_tbl, u8 channel_used_num);
/******************************* Stack Interface End *******************************************************************/


/******************************* User Interface  Begin *****************************************************************/
void blc_ll_initChannelSelectionAlgorithm_2_feature(void);
/******************************* User Interface  End  ******************************************************************/
#endif
#endif /* LL_CONN_CSA_H_ */
