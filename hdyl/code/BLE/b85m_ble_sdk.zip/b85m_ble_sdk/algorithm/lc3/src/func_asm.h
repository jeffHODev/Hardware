#ifndef _FUNC_ASM_H
#define _FUNC_ASM_H

Word32 dprod_q15(Word16 *src1, Word16 *src2, Word32 size);

#endif
